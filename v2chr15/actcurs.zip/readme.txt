7/27/99 (ver 2.00)
Cursors by Actinium

37 different cursors to go with the v2chr editor made by rane. Find
the cursor you want, rename to cursor.pcx, copy to the directory of
the editor, overright, then run the program and it will work.
Need to thank Default for doing a few :)