#include <conio.h>
#include <stdio.h>

int main()
{ char k;

  while(k!=13)
  { k=getch();
    printf(" %c = %d\n",k,k);
  }

return 0; }
