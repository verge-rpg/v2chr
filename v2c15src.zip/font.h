/* FONT.H header file for modified FONT.C font functions */

extern unsigned char *fontset;
extern void (*blitfont)(int x, int y, unsigned char *string,unsigned char c);
extern void fontfuncs();

/* end of file */
